INSTRUCTIONS:
run the MistyRecognize.py python script in the yolov5-master folder. You will be prompted to input the IP of the Misty robot you want to use. If you are using the same misty robot that was used in development, typing "default" in instead may pick up the correct IP

DESCRIPTION:
Final project code for Team Joshua for Artificial Intelligence.

The majority of the code included is from YOLOv5 at https://github.com/ultralytics/yolov5, though the detect.py script was modified to directly return a list of what was detected. The MistyDetect.py file was entirely created by Team Joshua.