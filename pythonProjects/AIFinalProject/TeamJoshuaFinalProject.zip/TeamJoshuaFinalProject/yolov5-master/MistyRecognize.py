import base64
import json
import os
import requests

import time
import detect

mistyIP = "10.13.134.81"

timeDelay = 2

parameters = {
    "base64": "true",
    "filename": "joshuaImageRecognitionPhoto"
}

def takePicture():
    global mistyIP
    global parameters
    imageFileName = "image.jpg"
    
    #ask misty to take a picture
    response = requests.get(f"http://{mistyIP}/api/cameras/rgb", params=parameters)
    #convert content of response from base64 format to json
    jsonResponse = bytesToJSON(response.content)

    #save picture
    with open(imageFileName, "wb") as f:
        f.write(base64.b64decode(jsonResponse["result"]["base64"]))
    print(f"Image saved as {imageFileName}")


def bytesToJSON(response_content_bytes):
    response_content_string = response_content_bytes.decode('utf-8')
    json_format = json.loads(response_content_string)
    return(json_format)

def main():
    global mistyIP
    global timedelay

    #make misty look straight ahead
    straightAhead = {"roll":"0","pitch":"0","yaw":"0","duration":"1"}
    requests.post(f"http://{mistyIP}/api/head", params=straightAhead)
    
    ipToUse = input('Misty IP (uses misty#4\'s expected IP if "default" is typed in): ')
    if ipToUse != "default":
        mistyIP = ipToUse

    lastSeen = []
    while True:
        takePicture()
        
        output = detect.run(source="image.jpg")
        items = output.split("|")
        #trim off empty string
        items = items[:-1]
        items.sort()
        newItems = set(items)-set(lastSeen)
        print("New items:",newItems)
        if len(newItems)==0:
            time.sleep(timeDelay)
            continue
        
        for item in newItems:
            parameters = {
                "Text": f"<speak>I see a {item}</speak>",
                "Flush": False,
                "UtteranceId": "First"
            }
            #ask misty to take a picture
            response = requests.post(f"http://{mistyIP}/api/tts/speak", params=parameters)
            #convert content of response from base64 format to json
            time.sleep(timeDelay)
        
        lastSeen = items
        time.sleep(timeDelay)
    

if __name__ == "__main__":
    main()
